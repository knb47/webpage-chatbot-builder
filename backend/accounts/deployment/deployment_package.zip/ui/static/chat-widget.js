(function() {
  // Insert the HTML for the chat widget
  const widgetHTML = `
      <div id="chat-launcher">Chat with AI</div>
      <div id="chat-widget">
          <div id="chat-header">
              <h3 id="chat-title">Chat with AI</h3>
              <button id="close-chat">×</button>
          </div>
          <div id="messages"></div>
          <div class="typing-indicator" id="typingIndicator">AI is typing<span>.</span><span>.</span><span>.</span></div>
          <div id="chat-input">
              <input type="text" id="promptInput" placeholder="Type your message...">
              <button id="sendButton">Send</button>
          </div>
      </div>
  `;

  // Insert the CSS for the chat widget
  const styleElement = document.createElement('style');
  styleElement.textContent = `
      #chat-widget {
          position: fixed;
          bottom: 20px;
          right: 20px;
          width: 300px;
          height: 400px;
          background-color: white;
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
          display: none;
          flex-direction: column;
          overflow: hidden;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          z-index: 1000;
      }

      #chat-header {
          background-color: #007BFF;
          color: white;
          padding: 10px;
          display: flex;
          justify-content: space-between;
          align-items: center;
      }

      #chat-title {
          margin: 0;
          font-size: 1rem;
      }

      #close-chat {
          background: none;
          border: none;
          color: white;
          font-size: 1.2rem;
          cursor: pointer;
      }

      #messages {
          flex: 1;
          overflow-y: auto;
          padding: 10px;
          background-color: #f9f9f9;
      }

      .message {
          margin-bottom: 10px;
          padding: 8px;
          border-radius: 5px;
          max-width: 80%;
      }

      .message.user {
          background-color: #d1e7dd;
          margin-left: auto;
      }

      .message.bot {
          background-color: #f8d7da;
          margin-right: auto;
      }

      #chat-input {
          display: flex;
          padding: 10px;
          background-color: white;
      }

      #promptInput {
          flex: 1;
          padding: 5px;
          border: 1px solid #ccc;
          border-radius: 3px;
      }

      #sendButton {
          margin-left: 5px;
          padding: 5px 10px;
          background-color: #007BFF;
          color: white;
          border: none;
          border-radius: 3px;
          cursor: pointer;
      }

      #chat-launcher {
          position: fixed;
          bottom: 20px;
          right: 20px;
          background-color: #007BFF;
          color: white;
          padding: 10px 20px;
          border-radius: 25px;
          cursor: pointer;
          box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
          z-index: 1000;
      }

      .typing-indicator {
          display: none;
          color: #aaa;
          font-style: italic;
          text-align: left;
          margin-bottom: 10px;
      }

      .typing-indicator span {
          display: inline-block;
          animation: ellipsis 1.25s infinite;
      }

      .typing-indicator span:nth-child(2) {
          animation-delay: 0.25s;
      }

      .typing-indicator span:nth-child(3) {
          animation-delay: 0.5s;
      }

      @keyframes ellipsis {
          0% { opacity: 0; }
          25% { opacity: 1; }
          100% { opacity: 0; }
      }
  `;

  // Append the HTML and CSS to the document
  document.body.insertAdjacentHTML('beforeend', widgetHTML);
  document.head.appendChild(styleElement);

  // Function to initialize the chat widget
  function initChatWidget() {
      const chatWidget = document.getElementById('chat-widget');
      const chatLauncher = document.getElementById('chat-launcher');
      const closeChat = document.getElementById('close-chat');
      const messagesDiv = document.getElementById('messages');
      const typingIndicator = document.getElementById('typingIndicator');
      const promptInput = document.getElementById('promptInput');
      const sendButton = document.getElementById('sendButton');

      let userLog = [];
      let currentState = null;
      let subState = null;
      let action = null;

      chatLauncher.addEventListener('click', () => {
          chatWidget.style.display = 'flex';
          chatLauncher.style.display = 'none';
      });

      closeChat.addEventListener('click', () => {
          chatWidget.style.display = 'none';
          chatLauncher.style.display = 'block';
      });

      function appendMessage(sender, message) {
          const messageDiv = document.createElement('div');
          messageDiv.classList.add('message', sender);
          messageDiv.innerHTML = marked.parse(message);
          messagesDiv.appendChild(messageDiv);
          messagesDiv.scrollTop = messagesDiv.scrollHeight;
      }

      async function sendMessage() {
        const userMessage = promptInput.value.trim();
        
        if (userMessage === '') {
            return;
        }
    
        appendMessage('user', userMessage);
        promptInput.value = '';
        typingIndicator.style.display = 'block';
    
        userLog.push({ sender: 'user', message: userMessage });
    
        // Keep only the last two messages
        if (userLog.length > 2) {
            userLog = userLog.slice(-2);
        }
    
        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    user_log: userLog,
                    current_state: currentState,
                    sub_state: subState,
                    action: action
                })
            });
    
            if (!response.ok) {
                throw new Error('Failed to send message');
            }
    
            const responseData = await response.json();
            appendMessage('bot', responseData.response_for_user);
    
            // Update the state variables with the new values from the backend
            currentState = responseData.current_state;
            subState = responseData.sub_state;
            action = responseData.action;
    
        } catch (error) {
            console.error('Error fetching response:', error);
            appendMessage('bot', 'Sorry, there was an error processing your request.');
        } finally {
            typingIndicator.style.display = 'none';
        }
      }

      sendButton.addEventListener('click', sendMessage);
      promptInput.addEventListener('keypress', function(event) {
          if (event.key === 'Enter') {
              sendMessage();
          }
      });
  }

  // Load the marked library for Markdown support
  const script = document.createElement('script');
  script.src = 'https://cdn.jsdelivr.net/npm/marked/marked.min.js';
  script.onload = initChatWidget; // Call initChatWidget function after marked.js is loaded
  document.head.appendChild(script);
})();