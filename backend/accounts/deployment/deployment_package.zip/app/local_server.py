from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import Any, Optional, List
from app.chat_engine.chat_engine import ChatEngine
import logging
from pathlib import Path

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("openai").setLevel(logging.WARNING)

class UserLogEntry(BaseModel):
    sender: str
    message: str

class QueryResponse(BaseModel):
    response_for_user: str
    current_state: Optional[Any] = None
    sub_state: Optional[Any] = None
    action: Optional[Any] = None

class ChatRequest(BaseModel):
    user_log: List[UserLogEntry]
    current_state: Optional[Any] = None
    sub_state: Optional[Any] = None
    action: Optional[Any] = None

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=BASE_DIR / 'ui/templates')

app = FastAPI()

app.mount("/static", StaticFiles(directory=BASE_DIR / "ui/static"), name="static")

chat_engine = ChatEngine()

@app.get("/", response_class=HTMLResponse)
async def get_chat(request: Request):
    try:
        return templates.TemplateResponse("index.html", {"request": request})
    except Exception as e:
        logger.error("Error rendering the template: %s", e)
        raise HTTPException(status_code=500, detail="Template rendering failed.")

@app.post("/chat", response_model=QueryResponse)
async def query(request: ChatRequest):
    if request.current_state is None:
        request.current_state = ""
    if request.sub_state is None:
        request.sub_state = ""
    if request.action is None:
        request.action = ""
    try:
        logger.debug("Received user log: %s", request.user_log)
        logger.debug("Current state: %s", request.current_state)
        logger.debug("Sub state: %s", request.sub_state)
        logger.debug("Action: %s", request.action)

        response_object = chat_engine.invoke(
            request.user_log, request.current_state, request.sub_state, request.action
        )
        logger.debug("Response for user: %s", response_object.response)
        logger.debug("New state: %s", response_object.current_state)
        logger.debug("Sub state: %s", response_object.sub_state)
        logger.debug("Action: %s", response_object.action)

        response_for_user = response_object.response
        current_state = response_object.current_state
        sub_state = response_object.sub_state
        action = response_object.action

    except Exception as e:
        logger.error("Error during query processing: %s", e)
        response_for_user = "I apologize. Something went wrong on my end, and I'm unable to complete your request. Our chat engine must be down. Please try again later or notify a representative."
        current_state = request.current_state
        sub_state = request.sub_state
        action = request.action

    return QueryResponse(
        response_for_user=response_for_user, current_state=current_state, sub_state=sub_state, action=action
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3001)