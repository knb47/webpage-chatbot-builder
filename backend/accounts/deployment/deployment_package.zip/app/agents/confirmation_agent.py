from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable
from langchain_core.output_parsers import StrOutputParser

def _ask_action_confirmation_template():
    return ChatPromptTemplate.from_messages([
        ("system",
                "You're a helpful assistant that facilitates a human user through user journey of pre-defined states."
                "The user has indicated that they want to use a tool or perform an api action based on your last response."
                "The user has indicated that they want to perform the following action in their prior message: {action}."
                "Your job is to simlpy ask the user if they wish to proceed with that action by responding with the following description of the action: {action_description}."
                "You can formulate your response in a more friendly manner given the action description."
                "You can also provide the user with the following information about the tool library: {tool_description}."
                "The other actions available in the tool library are: {tool_actions}."
                "Don't sound like a robot or acknowledge the library's existence. Just ask the user if they want to proceed with the action and add some friendly context."
                "Try to say something like: 'I can help you with {action_description}.' Instead of something like 'you're about to perform this action'."
        ),
        ("user",
            "User input: {user_input}\n"
            "Based on the user's input, ask the user if they want to proceed with the action: {action_description}."
        ),
    ])

def _process_action_confirmation_template():
    return ChatPromptTemplate.from_messages([
        ("system",
                "You're a helpful assistant that facilitates a human user through user journey of pre-defined states."
                "The user has indicated that they want to perform an action and you have asked for confirmation."
                "The user response you see is their response to your confirmation request."
                "If the user has indicated they definitively want to proceed or they confirm, return 'confirm'."
                "Any other responses that are unclear or are not definitively yes, you must return 'deny'."
                "Please return only one of the following: 'confirm', 'deny'."
        ),
        ("user",
            "User input: {user_input}\n"
            "Based on the user's input, return 'confirm' or 'deny'."
        ),
    ])

class _AskActionConfirmationAgent:
    """Determines the next best state based on user input and current state using a language model."""
    def __init__(self, llm):
        self.model = llm
        self.prompt_template = _ask_action_confirmation_template()

    def ask_confirmation(self, action_id, action_description, tool, tool_description, tool_actions, user_input):
        """Infer the next state based on user input using a language model."""
        data = {
            "action": action_id,
            "action_description": action_description,
            "tool_name": tool,
            "tool_description": tool_description,
            "tool_actions": tool_actions,
            "user_input": user_input,
        }

        try:
            prompt = self.prompt_template.invoke(data)
        except Exception as e:
            print(f"Error in invoking prompt: {e}")
        llm_response = self.model.invoke(prompt)
        parser = StrOutputParser()
        response = parser.invoke(llm_response)
        return response

class AskActionConfirmationAgentRunnable(Runnable):
    """Runnable class to encapsulate the decision and execution process for state changes."""
    def __init__(self, llm):
        self.agent = _AskActionConfirmationAgent(llm)

    def invoke(self, current_action, action_description, tool, tool_description, tool_actions, user_input):
        """Invoke the process to infer and execute the next state."""
        response_to_confirm_with_user = self.agent.ask_confirmation(current_action, action_description, tool, tool_description, tool_actions, user_input)
        return response_to_confirm_with_user
    
class _ProcessConfirmationAgent:
    """Determines the next best state based on user input and current state using a language model."""
    def __init__(self, llm):
        self.model = llm
        self.prompt_template = _ask_action_confirmation_template()
    
    def process_confirmation(self, user_input):
        """Processes user input to determine whether to proceed with something or not."""
        data = {
            "user_input": user_input,
        }
        prompt = _process_action_confirmation_template().invoke(data)
        llm_response = self.model.invoke(prompt)
        parser = StrOutputParser()
        response = parser.invoke(llm_response)
        return response
    
class ProcessConfirmationAgentRunnable(Runnable):
    """Runnable class to encapsulate the decision and execution process for state changes."""
    def __init__(self, llm):
        self.agent = _ProcessConfirmationAgent(llm)

    def invoke(self, user_input):
        """Invoke the process to infer and execute the next state."""
        how_to_proceed_action = self.agent.process_confirmation(user_input)
        return how_to_proceed_action
    
__all__ = ["NextStateAgentRunnable"]