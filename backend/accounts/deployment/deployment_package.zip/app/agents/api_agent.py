from abc import ABC, abstractmethod
import requests
import json
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableSequence
from typing import Dict, Any
from pydantic import ValidationError
from typing import get_origin, get_args, Annotated, Union
from app.build.actions import APIResponse
import time
from dependency_injector.wiring import inject, Provide
from app.containers.containers import Container


class APIAgentState(ABC):
    @abstractmethod
    def make_request(self, ApiAgentInstance, api_id, params, user_input=None):
        pass

    @abstractmethod
    def handle_response(self, ApiAgentInstance, response):
        pass

# First step of a request


class IdleState(APIAgentState):
    def make_request(self, ApiAgentInstance, api_id, params=None, user_input=None):
        required_params = ApiAgentInstance.get_required_params(api_id)
        print(f"Required params: {required_params}")

        if not required_params:
            # If no params are required, proceed directly to fetching
            ApiAgentInstance.set_state(FetchingState())
            return ApiAgentInstance._state.make_request(ApiAgentInstance, api_id, params, user_input)

        # If params are required, always transition to ParamRequestState
        ApiAgentInstance.set_state(ParamRequestState())
        return ApiAgentInstance._state.make_request(ApiAgentInstance, api_id, params, user_input)

    # Not used in this state
    def handle_response(self, ApiAgentInstance, response):
        print("No active request to handle in Idle state.")
        return response

# Second step of a request (if required params are present)


class ParamRequestState(APIAgentState):
    def make_request(self, ApiAgentInstance, api_id, params=None, user_input=None):
        print("APIAgent working on params for the request.")
        required_params = ApiAgentInstance.get_required_params(api_id)

        if params:
            valid_result = ApiAgentInstance.validate_params(api_id, params)
            if valid_result:
                ApiAgentInstance.set_state(FetchingState())
                return ApiAgentInstance._state.make_request(ApiAgentInstance, api_id, params, user_input)

        if user_input:
            formatted_params = ApiAgentInstance.format_params(
                required_params, user_input)
            valid_result = ApiAgentInstance.validate_params(
                api_id, formatted_params)
            if valid_result:
                print(
                    f"Successfully formatted params into a valid form: {formatted_params}")
                ApiAgentInstance.set_state(FetchingState())
                return ApiAgentInstance._state.make_request(ApiAgentInstance, api_id, formatted_params, user_input)

        response = {
            "api_agent_response": "Required params are not provided or invalid to use this api. Please ask the user to provide the following required params if they wish to complete this current action.",
            "Required_params": required_params
        }
        return ApiAgentInstance._state.handle_response(ApiAgentInstance, response)

    # catch and return the response to user
    def handle_response(self, ApiAgentInstance, response):
        print("Requesting the params from the user.")
        return response

# Third step of a request


class FetchingState(APIAgentState):
    def __init__(self):
        self.is_fetching = False

    def make_request(self, ApiAgentInstance, api_id, params=None, user_input=None):
        # Catch concurrent requests
        if self.is_fetching:
            print("A request is already in progress. Please wait.")
            return {
                "status": "pending",
                "message": "A request is already in progress. Please wait."
            }

        self.is_fetching = True
        ApiAgentInstance.last_fetch = {
            "api_id": api_id,
            "params": params
        }
        try:
            print("Fetching data...")
            response = ApiAgentInstance.actual_make_request(api_id, params)
            return ApiAgentInstance._state.handle_response(ApiAgentInstance, response)
        finally:
            self.is_fetching = False

    def handle_response(self, ApiAgentInstance, response):
        if response.ok:
            print("Request completed successfully.")
            ApiAgentInstance.set_state(SuccessState())
            return ApiAgentInstance._state.handle_response(ApiAgentInstance, response)
        elif response.status_code >= 500:
            print("Request failed, moving to error state and retrying.")
            ApiAgentInstance.set_state(ErrorState())
            return ApiAgentInstance._state.make_request(ApiAgentInstance, ApiAgentInstance.last_fetch['api_id'], ApiAgentInstance.last_fetch['params'])
        else:
            print("Request failed - bad request.")
            ApiAgentInstance.set_state(ErrorState())
            return ApiAgentInstance._state.handle_response(ApiAgentInstance, response)

# After fetching


class SuccessState(APIAgentState):
    # Not used in this state
    def make_request(self, ApiAgentInstance, api_id, params=None, user_input=None):
        print("Previous request was successful. Please start a new request")

    # Catch and return the response to user
    def handle_response(self, ApiAgentInstance, response):
        return {
            "status": "success",
            "status_code": response.status_code,
            "message": "Request completed successfully.",
            "data": response.json()
        }


class ErrorState(APIAgentState):
    MAX_RETRIES = 1
    RETRY_DELAY = 2  # seconds

    def __init__(self):
        self.retry_count = 0

    def make_request(self, ApiAgentInstance, api_id, params=None, user_input=None):
        response = None
        while self.retry_count < self.MAX_RETRIES:
            print(
                f"Previous request failed. Retrying (Attempt {self.retry_count + 1}/{self.MAX_RETRIES})...")
            self.retry_count += 1
            time.sleep(self.RETRY_DELAY)
            response = ApiAgentInstance.actual_make_request(api_id, params)
            if response.status_code == 200:
                ApiAgentInstance.set_state(SuccessState())
                return ApiAgentInstance._state.handle_response(ApiAgentInstance, response)
        return ApiAgentInstance._state.handle_response(ApiAgentInstance, response)

    def handle_response(self, ApiAgentInstance, response):
        return {
            "status": "error",
            "status_code": response.status_code,
            "message": "Request failed",
            "error": response.error,
            "data": response.json() if response.json() else None
        }

class APIAgent:
    custom_stream=Provide[Container.custom_stream]
    def __init__(self, action_manager, llm):
        self._state = IdleState()  # Set initial state
        self.llm = llm
        self.action_manager = action_manager
        self.param_format_agent = self._create_param_format_agent()
        self.call_dict = action_manager.action_call_dict
        self.params_dict = action_manager.action_params_dict
        self.last_fetch = None

    def get_required_params(self, api_id):
        params_model = self.params_dict.get(api_id)
        if not params_model:
            return []

        required_params = []
        for field_name, field_info in params_model.__fields__.items():
            field_type = field_info.annotation
            if get_origin(field_type) is Annotated:
                field_type = get_args(field_type)[0]

            field_constraints = {
                "type": self._simplify_type(field_type),
                "description": field_info.description,
                "required": field_info.is_required()
            }

            # Add constraints
            if hasattr(field_info.annotation, '__constraints__'):
                constraints = field_info.annotation.__constraints__
                field_constraints.update(constraints)

            # Remove None values
            field_constraints = {
                k: v for k, v in field_constraints.items() if v is not None}

            required_params.append({field_name: field_constraints})

        return required_params

    def _simplify_type(self, field_type):
        if get_origin(field_type) is Union:
            types = get_args(field_type)
            if type(None) in types:
                return f"Optional[{self._simplify_type(types[0])}]"
        return field_type.__name__

    def _create_param_format_agent(self):
        prompt_template = PromptTemplate.from_template("""
        Given the following information:
        Required parameters: {required_params}
        User input: {user_input}

        Extract and format the required parameters from the user input if possible.
        Return only a JSON object with the parameter names as keys and the extracted values.
        If a required parameter is missing or cannot be extracted, leave its value as null.
        If it is not possible to format any of the Required parameters from the User input, return an empty JSON object.

        Formatted parameters:
        """)

        return RunnableSequence(prompt_template, self.llm)

    def format_params(self, required_params, user_input):
        required_params_str = json.dumps(required_params)
        formatted_params = self.param_format_agent.invoke({
            "required_params": required_params_str,
            "user_input": user_input
        })
        try:
            formatted_params = formatted_params.content if hasattr(
                formatted_params, 'content') else str(formatted_params)
            return json.loads(formatted_params.strip())
        except json.JSONDecodeError:
            return {}

    def validate_params(self, api_id, params):
        params_model = self.params_dict.get(api_id)
        if not params_model:
            raise ValueError(f"No parameters model found for api_id: {api_id}")
        try:
            params_model(**params)
            return True
        except ValidationError:
            return False

    def set_state(self, state):
        self._state = state

    def make_request(self, api_id, params=None, user_input=None):
        self.custom_stream.log_activity(
            "APIAgent", f"Making request to API: {api_id}")
        response = self._state.make_request(self, api_id, params, user_input)
        # set state to idle
        self.set_state(IdleState())
        self.last_fetch = None

        # If response is already a dictionary, return it directly
        if isinstance(response, dict):
            self.custom_stream.log_activity(
                "APIAgent", f"API response: {json.dumps(response, indent=2)}")
            return response

        # If it's our custom APIResponse, convert it to a dictionary
        if isinstance(response, APIResponse):
            response = {
                "status": "success" if response.ok else "error",
                "status_code": response.status_code,
                "message": "Request completed successfully." if response.ok else "Request failed",
                "data": response.json(),
                "error": response.error
            }
            self.custom_stream.log_activity("APIAgent", f"API response: {json.dump(response)}")
            return response

        # If it's a requests.Response object, convert it to a dictionary
        if isinstance(response, requests.Response):
            try:
                data = response.json()
            except ValueError:
                data = response.text

            response = {
                "status": "success" if response.ok else "error",
                "status_code": response.status_code,
                "message": "Request completed successfully." if response.ok else "Request failed",
                "data": data
            }
            self.custom_stream.log_activity("APIAgent", f"API response: {json.dump(response)}")
            return response

        # If it's none of the above, return an error
        response = {
            "status": "error",
            "message": "Unexpected response type",
            "data": str(response)
        }
        self.custom_stream.log_activity("APIAgent", f"API response: {json.dump(response)}")
        return response

    def debug_field_info(self, api_id):
        params_model = self.action_manager.action_params_dict.get(api_id)
        if not params_model:
            print(f"No params model found for {api_id}")
            return

        print(f"Debugging field info for {api_id}:")
        for field_name, field in params_model.__fields__.items():
            print(f"Field: {field_name}")
            print(f"  Type: {type(field)}")
            print(f"  Attributes: {dir(field)}")
            print(f"  Annotation: {field.annotation}")
            if hasattr(field, 'field_info'):
                print(f"  Field Info: {field.field_info}")
                print(f"  Field Info Attributes: {dir(field.field_info)}")
            print("---")

    def actual_make_request(self, api_id, params):
        try:
            response = self.call_dict[api_id](params)
            if isinstance(response, APIResponse):
                return response
            elif isinstance(response, requests.Response):
                # If it's a requests.Response object, convert it to our custom APIResponse
                return APIResponse(response.status_code, response.json(), response.reason)
            else:
                # If it's neither, something unexpected happened
                return APIResponse(500, None, "Unexpected response type")
        except requests.RequestException as e:
            # Handle network-related errors
            return APIResponse(getattr(e.response, 'status_code', 500), None, str(e))
        except Exception as e:
            # Handle any other unexpected errors
            return APIResponse(500, None, str(e))
