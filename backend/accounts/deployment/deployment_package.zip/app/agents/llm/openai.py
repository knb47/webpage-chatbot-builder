
import os
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv, find_dotenv
import openai

load_dotenv(find_dotenv())

openai_api_key = os.getenv("OPENAI_API_KEY")

# Set the OpenAI API key
openai.api_key = openai_api_key

def openai_gpt4_llm():
  llm = ChatOpenAI(api_key=openai_api_key, model_name="gpt-4", temperature=0.5)
  return llm

def openai_gpt4o_llm():
  llm = ChatOpenAI(api_key=openai_api_key, model_name="gpt-4o", temperature=0.5)
  return llm