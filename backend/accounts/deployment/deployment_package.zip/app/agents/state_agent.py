from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable
from langchain_core.output_parsers import StrOutputParser

def _next_state_template():
    return ChatPromptTemplate.from_messages([
        ("system",
                "Based on the users input and the available transitions, what is the next best state? Use the information in available transitions to determine the next state. The return only the next state name."
                "For example, if the current state is 'start' and the user input is 'I want to buy a product', looking at the triggers info, the next state would be 'shopping'."
                "You would then return only the next state name 'shopping'."
                "If no state transition seems plausible (perhaps the users intent is to remain in the current state) return 'defer'."
        ),
        ("user",
            "Current state: {current_state}\n"
            "User input: {user_input}\n"
            "Available transitions: {transitions}\n"
            "Based on the users input and the available transitions, what is the next best state? Use the information in available transitions to determine the next state. The return only the next state name."
        ),
    ])

class _NextStateAgent:
    """Determines the next best state based on user input and current state using a language model."""
    def __init__(self, llm):
        self.model = llm
        self.prompt_template = _next_state_template()

    def infer_next_state(self, user_input, current_state_name, transitions):
        """Infer the next state based on user input using a language model."""
        data = {
            "current_state": current_state_name,
            "user_input": user_input,
            "transitions": transitions
        }
        prompt = self.prompt_template.invoke(data)
        llm_response = self.model.invoke(prompt)
        parser = StrOutputParser()
        next_state = parser.invoke(llm_response)
        return next_state

class NextStateAgentRunnable(Runnable):
    """Runnable class to encapsulate the decision and execution process for state changes."""
    def __init__(self, llm):
        self.agent = _NextStateAgent(llm)

    def invoke(self, user_input, current_state_name, transitions):
        """Invoke the process to infer and change the state."""
        next_state = self.agent.infer_next_state(user_input, current_state_name, transitions)
        return next_state
    
__all__ = ["NextStateAgentRunnable"]