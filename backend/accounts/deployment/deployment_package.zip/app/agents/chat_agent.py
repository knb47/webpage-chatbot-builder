from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableSequence
from app.agents.llm.openai import openai_gpt4_llm
import json

class ChatAgentRunnable:
    def __init__(self,llm):
        self.prompt_template = ChatPromptTemplate.from_messages([
            ("system",
              "You're a helpful assistant that facilitates a human user through user journey of pre-defined states."
              "You're job is to help the user move to the next state in the user journey (help guide the user through the process)."
              "The current state of the user journey you're in is: {current_state}."
              "The user got to this state because they completed this previous action: {trigger}."
              "The goal of the current state: {goal}."
              "Helpful info to provide user if they need guidance: {info}."
              "After the user's input, you will see the output (context) of other the other agents after they have completed their tasks based on the user input."
              "The context provided by the other agents should help you formulate your response to the human user."
              "Look at what these other agents have decided to do and then return a response to the user on the status of their results if necessary."
              "For example, a user input might've executed an api action by another agent, in which case you should tell them about the status of the result."
              "Do not refer to any previous conversation history or acknowledge the context of the conversation in front of the user."
              "The conversation is between you and the user. The context is there to help you as an assistant."
              "If the context isn't helpful, then the user's input, current state, goal, and info should be enough to help you formulate a response."
              "Your ultimate goal should be to guide the user to the next state in the conversation."
              "Here are the ways the user can enter a new state: {next_state_triggers}."
              "Based on their input, the user may also perform the following actions: {actions}."
              "These are the only actions that a user can execute in the current state."
              "For example, if a user wants to do something like shedule an appointment, but it's not in the list of actions helper agents can perform, then you should tell them that you can't help them with this."
              "Don't mention anything explicitly about 'states', just mention it as a 'step' and 'the next step in the process to you'."
              "Never try to help a user in a way that you can't. If your helper agents didn't perform an action after the user response, it can't be done."
              "You can only help guide the user to the next state and respond helpfully using context provided to you."
              "It's better to be unhelpful than to promise something you can't deliver."
              "You can also provide the user with the following information (format it for the user in a presentable manner): {info}."
              "If api action has been performed by another helpful agent based on the user's input, respond saying you completed the action along with information to the user."
              "If the action has already been completed, don't ask for confirmation from the user."
              "If the the action agent in context tells you to provide information to the user, provide the user with the information."
              "If the action failed, explain to the user that the action failed and why it failed. (Example: The request failed due to an internal error associated with this action. Please try again later.)"
              "(Please don't use any bold formatting in your markdown responses. Keep it simple and clean.)"
            ),
            ("human", "{user_input}"),
            ("system", "Context from other helper agents: {context}"),
        ])
        self.sequence = RunnableSequence(self.prompt_template, llm)

    def invoke(self, chat_args):
        input_data = {
            "user_input": chat_args['user_log'],
            "context": chat_args['meeting_notes'],
            "current_state": chat_args['current_state'],
            "goal": chat_args['current_state_goal'],
            "info": chat_args['info_to_provide'],
            "trigger": chat_args['trigger'],
            "next_state_triggers": chat_args['next_states_and_conditions'],
            "actions": chat_args['actions_and_info_available'],
        }
        
        print("Input data for LLM:")
        print(json.dumps(input_data, indent=2))
        
        response = self.sequence.invoke(input_data)
        print("Chat response from llm completed.")
        return response.content if hasattr(response, 'content') else str(response)