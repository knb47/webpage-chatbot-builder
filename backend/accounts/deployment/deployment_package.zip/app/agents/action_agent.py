from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable
from langchain_core.output_parsers import StrOutputParser
import logging

# used for formatting strings w/ variables
def _next_action_template():
    return ChatPromptTemplate.from_messages([
        ("system",
                "Based on the users input and the available actions, what is the next best action? Use the information in available actions to determine the action to use. Then return only the next action name."
                "For example, if the user's input is 'I want to buy a product', but this response is not enough to determine the next action, then you would return 'provide' to provide more information."
                "If the user's input is 'I want to create an order', and 'create_order' is among the available actions, then you would return 'create_order'."
                "If no actions seems plausible to help the user achieve the goal of this state (perhaps the user intent is something else) return 'defer'."
        ),
        ("user",
            "Current state: {current_state}\n"
            "Current state goal: {current_goal}\n"
            "User input: {user_input}\n"
            "Available actions: {actions}\n"
            "Based on the users input and the available actions, how should we proceed? Return your response with only the action_name, 'provide', or 'defer'."
        ),
    ])

def _next_tool_template():
    return ChatPromptTemplate.from_messages([
        ("system",
                "Tools are used to help achieve the current state's goal to help the user. Tools have various actions within them that you can execute. We must determine if we should use a tool and what tool to use."
                "Based on the users input and the tools available, what is the best tool to use? Use the information in Available tools to determine what tool to use. Then return only the tool_id."
                "If no tools seems plausible to help the user achieve the goal of this state (perhaps the user is satisfied or making small conversation) return 'defer'."
                "For example, if the user's input is 'I'm alright for now', then you would return 'defer' to defer the decision to use a tool."
                "If the user's input is 'I want to create an order' and the tool_id 'shopping' seems like the best tool, then you would return 'shopping'."
        ),
        ("user",
            "Current state: {current_state}\n"
            "Current state goal: {current_goal}\n"
            "User input: {user_input}\n"
            "Available tools: {tools}\n"
            "Based on the users input and the available tools, how should we proceed? Return your response with only the '*tool_id*' or 'defer'."
        ),
    ])

class _NextActionAgent:
    """Determines the next best action based on user input and current state using a language model."""
    def __init__(self, llm):
        self.model = llm
        self.prompt_template = _next_action_template()

    def infer_next_action(self, user_input, current_state_name, goal, actions_available):
        """Infer the next action based on user input using a language model."""
        data = {
            "current_state": current_state_name,
            "current_goal": goal,
            "user_input": user_input,
            "actions": actions_available
        }
        prompt = self.prompt_template.invoke(data)
        llm_response = self.model.invoke(prompt)
        parser = StrOutputParser()
        return parser.invoke(llm_response)

class NextActionAgentRunnable(Runnable):
    """Runnable class to encapsulate the decision and execution process."""
    def __init__(self, llm):
        self.agent = _NextActionAgent(llm)

    def invoke(self, user_input, current_state_name, goal, actions_available):
        """Invoke the process to infer and execute the action."""
        next_action = self.agent.infer_next_action(user_input, current_state_name, goal, actions_available)
        logging.debug(f"Next action: {next_action}")
        return next_action
    
class _NextToolAgent:
    """Determines the next best action based on user input and current state using a language model."""
    def __init__(self, llm):
        self.model = llm
        self.prompt_template = _next_tool_template()

    def infer_next_tool(self, user_input, current_state_name, goal, available_tools_and_info):
        """Infer the next action based on user input using a language model."""
        data = {
            "current_state": current_state_name,
            "current_goal": goal,
            "user_input": user_input,
            "tools": available_tools_and_info
        }
        prompt = self.prompt_template.invoke(data)
        llm_response = self.model.invoke(prompt)
        parser = StrOutputParser()
        return parser.invoke(llm_response)

class NextToolAgentRunnable(Runnable):
    """Runnable class to encapsulate the decision and execution process."""
    def __init__(self, llm):
        self.agent = _NextToolAgent(llm)

    def invoke(self, user_input, current_state_name, goal, available_tools_and_info):
        """Invoke the process to infer and execute the action."""
        logging.debug(f"Available tools: {available_tools_and_info}")
        next_tool = self.agent.infer_next_tool(user_input, current_state_name, goal, available_tools_and_info)
        logging.debug(f"Next tool: {next_tool}")
        return next_tool
    
__all__ = ["NextActionAgentRunnable", "NextToolAgentRunnable"]