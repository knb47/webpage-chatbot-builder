import logging
import json
from dependency_injector.wiring import Provide
from app.agents.llm.openai import openai_gpt4o_llm, openai_gpt4_llm
from app.execs.service import ExecService
from app.containers.containers import Container, CustomStream
from pydantic import BaseModel
from typing import Any, Optional, List

class UserResponse(BaseModel):
    response: str
    current_state: str
    sub_state: Optional[str] = None
    action: Optional[str] = None

class UserLogEntry(BaseModel):
    sender: str
    message: str

class ChatEngine:
    custom_stream: CustomStream = Provide[Container.custom_stream]

    def __init__(self):
        self.llm_fast = openai_gpt4o_llm()
        self.llm_smart = openai_gpt4_llm()
        self.president = ExecService(self.llm_smart)
        self.confirmation = True

    def log_agent_responses_di(self):
        container = Container()
        container.init_resources()
        container.wire(modules=[
            "app.chat_engine.chat_engine",
            "app.execs.action_exec",
            "app.execs.state_exec",
            "app.agents.api_agent",
            "app.execs.service",
        ])
        container.custom_stream()
        return container

    def decide_steps(self, last_message, current_state):
        new_state = self.president.state_exec.attempt_new_state(last_message['message'], current_state)
        action = self.president.action_exec.decide_action(last_message['message'], new_state)
        return new_state, action

    def ask_confirmation(self, last_message, action):
        response_for_user = self.president.confirmation_exec.ask_action_confirmation(last_message['message'], action)
        return response_for_user

    def process_confirmation(self, last_message):
        response = self.president.confirmation_exec.process_confirmation(last_message['message'])
        return response

    def take_action(self, all_messages, action):
        all_messages_text = " ".join([entry['message'] for entry in all_messages.values()])
        self.president.action_exec.take_action(all_messages_text, action)

    def collect_notes(self, last_message, all_messages):
        meeting_notes = json.dumps(last_message)
        logs = self.custom_stream.flush_logs()
        logs_str = "".join([json.dumps(log) if isinstance(log, dict) else log for log in logs])  # Convert logs to strings
        meeting_notes += json.dumps(all_messages)
        meeting_notes += logs_str
        return meeting_notes

    def formulate_response_for_user(self, last_message, meeting_notes, current_state):
        logging.debug("Formulating response for user query.")
        try:
            chat_args = {
                'user_log': last_message,
                'current_state': current_state,
                'meeting_notes': meeting_notes,
                'current_state_goal': self.president.guide_service.state_manager.get_state_goal(current_state),
                'info_to_provide': self.president.guide_service.state_manager.get_provide_info(current_state),
                'trigger': self.president.guide_service.state_manager.get_current_trigger(current_state),
                'next_states_and_conditions': self.president.guide_service.state_manager.get_next_states_and_conditions(current_state),
                'actions_and_info_available': self.president.guide_service.state_manager.get_actions_and_info_available(current_state)
            }

            chat_agent_response = self.president.chat_exec.generate_response(chat_args)
            return chat_agent_response
        except Exception as e:
            logging.error("Error during query processing: %s", e)
            raise e

    def conclusive_response(self, last_message, current_state, all_messages):
        meeting_notes = self.collect_notes(last_message, all_messages)
        response = self.formulate_response_for_user(last_message, meeting_notes, current_state)
        return response

    def invoke(self, user_log, current_state, sub_state=None, action=None):
        user_log_dict = {f"{i}": entry.dict() for i, entry in enumerate(user_log)}
        last_message = user_log_dict[list(user_log_dict.keys())[-1]] if user_log_dict else None
        all_messages = user_log_dict

        if current_state is None or current_state == '':
            current_state = self.president.guide_service.state_manager.get_initial_state()
        
        agent_di = self.log_agent_responses_di()

        if sub_state == 'confirm_action':
            sub_state = 'process_action'

        try:
            if sub_state is None or sub_state == '':
                new_state, action = self.decide_steps(last_message, current_state)
                current_state = new_state
                sub_state = 'confirm_action' if action else None
                if sub_state is None:
                    response = self.conclusive_response(last_message, current_state, all_messages)
                    return UserResponse(response=response, current_state=current_state, sub_state=None, action=None)
              
            if sub_state == 'confirm_action':
                response = self.ask_confirmation(last_message, action)
                return UserResponse(response=response, current_state=current_state, sub_state=sub_state, action=action)
            
            if sub_state == 'process_action':
                result = self.process_confirmation(last_message)
                if result == 'confirm':
                    self.take_action(all_messages, action)
                    response = self.conclusive_response(last_message, current_state, all_messages)
                    return UserResponse(response=response, current_state=current_state, sub_state=None, action=None)
                else:
                    response = self.conclusive_response(last_message, current_state, all_messages)
                    return UserResponse(response=response, current_state=current_state, sub_state=None, action=None)
            else:
                raise ValueError("Invalid sub state")
        except Exception as e:
            logging.error("Error during query processing: %s", e)
            raise e
        finally:
            agent_di.shutdown_resources()