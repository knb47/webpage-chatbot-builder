from io import StringIO

class CustomStream:
    def __init__(self):
        # self.buffer = StringIO()
        self.logs = []

    # def write(self, message):
    #     self.buffer.write(message)
    #     self.flush()

    def log_activity(self, sender, message):
        self.logs.append({"sender": sender, "message": message})

    def flush_logs(self):
        flushed_logs = self.logs
        self.logs = []
        return flushed_logs

    def get_logs(self):
        return self.logs

    def reset_logs(self):
        self.logs = []

    def getvalue(self):
        return self.buffer.getvalue()

    def reset(self):
        self.buffer = StringIO()

from dependency_injector import containers, providers

class Container(containers.DeclarativeContainer):
    config = providers.Configuration()

    custom_stream = providers.Singleton(CustomStream)



