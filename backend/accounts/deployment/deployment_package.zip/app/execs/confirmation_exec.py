from app.agents.confirmation_agent import ProcessConfirmationAgentRunnable, AskActionConfirmationAgentRunnable
from dependency_injector.wiring import Provide
from app.containers.containers import Container

class ConfirmationExecutive:
    """Manages the initialization and interaction with the runnable for state changes."""
    custom_stream: Container.custom_stream = Provide[Container.custom_stream]
    
    def __init__(self, guide, llm):
        self.ask_action_confirmation_runnable = AskActionConfirmationAgentRunnable(llm)
        self.process_confirmation_runnable = ProcessConfirmationAgentRunnable(llm)
        self.guide = guide

    def ask_action_confirmation(self, user_input, action_id):
        """Run the process using the runnable to handle logic flow."""
        print(f"action name: {action_id}")
        action_description = self.guide.action_manager.get_action_info(action_id)
        print(f"action name: {action_description}")
        tool_name = action_id.split(':')[0]
        tool_description = self.guide.action_manager.get_tool_info(tool_name)
        tool_actions = self.guide.action_manager.get_all_action_info_from_tool(tool_name)

        try:
            confirmation_response_for_user = self.ask_action_confirmation_runnable.invoke(
              action_id,
              action_description,
              tool_name,
              tool_description,
              tool_actions,
              user_input
            )

            print(f"confirmation_response_for_user: {confirmation_response_for_user}")
        
        except Exception as e:
            print(f"Failed to change state: {e}")
        
        return confirmation_response_for_user
    
    def process_confirmation(self, user_input):
        """Run the process using the runnable to handle logic flow."""
        try:
            user_decision = self.process_confirmation_runnable.invoke(user_input)
            return user_decision
        except Exception as e:
            print(f"Failed to change state: {e}")
            return 'deny'

__all__ = ["ConfirmationExecutive"]