from app.execs.state_exec import StateExecutive
from app.execs.action_exec import ActionExecutive
from app.execs.confirmation_exec import ConfirmationExecutive
from app.execs.chat_exec import ChatExecutive
from app.build.guide_service import GuideService
from app.agents.api_agent import APIAgent

# composition root of action and state executives
class ExecService:
    def __init__(self,llm_smart, llm_fast = None):
        self.guide_service = GuideService()

        if llm_fast is None:
            llm_fast = llm_smart

        self.chat_exec = ChatExecutive(self.guide_service, llm_fast)
        self.state_exec = StateExecutive(self.guide_service, llm_smart)
        self.action_exec = ActionExecutive(self.guide_service, llm_smart)
        self.confirmation_exec = ConfirmationExecutive(self.guide_service, llm_smart)