from app.agents.action_agent import NextActionAgentRunnable, NextToolAgentRunnable
from app.agents.api_agent import APIAgent
from dependency_injector.wiring import Provide
from app.containers.containers import Container, CustomStream
import logging

class ActionExecutive:
    """Manages the initialization and interaction with the runnable."""
    custom_stream: CustomStream = Provide[Container.custom_stream]
    
    def __init__(self, guide, llm):
        self.tool_runnable = NextToolAgentRunnable(llm)
        self.action_runnable = NextActionAgentRunnable(llm)
        self.guide = guide
        self.api_agent = APIAgent(self.guide.action_manager,llm)

    # infer the best tool to use
    def _infer_from_tools(self, user_input, current_state):
        """Run the process using the runnable to handle logic flow."""
        logging.debug(f"Infering tools from this state: {current_state}")
        current_goal = self.guide.state_manager.get_state_goal(current_state)
        tools_available = self.guide.state_manager.get_tools_available(current_state)  # gets all tool names
        self.custom_stream.log_activity("ActionExecutive", f"Tools available: {tools_available}")
        tools_and_info_available = self.guide.state_manager.get_tools_and_info_available(current_state)
        logging.debug(f"All tools and info during inference: {tools_and_info_available}")

        tool_name = self.tool_runnable.invoke(user_input, current_state, current_goal, tools_and_info_available) # invoke the agent to find the best tool
        logging.debug(f"Selected tool: {tool_name}")
        if tool_name == 'defer':
            print("Forgoing the use of tools.")
            self.custom_stream.log_activity("ActionExecutive", "Forgoing the use of tools.")
            return None
        if tool_name not in tools_available:
            raise ValueError(f"Tool name '{tool_name}' not in available tools: {tools_available}")
        self.custom_stream.log_activity("ActionExecutive", f"Selected tool: {tool_name}")
        available_actions_and_info = self.guide.action_manager.get_all_action_info_from_tool(tool_name)

        # invoke the agent to find the best action
        api_id = self._infer_from_actions(user_input, available_actions_and_info, current_state)
        if api_id == 'defer':
            print("Forgoing the execution of an action within tools.")
            self.custom_stream.log_activity("ActionExecutive", "Forgoing the execution of an action within tools.")
            return None
        
        if api_id == 'provide':
            print("Providing action information to the user.")
            available_actions_and_info = self.guide.action_manager.get_all_action_info_from_tool(tool_name)
            self.custom_stream.log_activity("ActionExecutive", f"The user is close to completing an action but we need information from the user to proceed. Provide the user with the a summary of the following available actions: {available_actions_and_info}")
            return None

        if api_id not in available_actions_and_info:
            raise ValueError(f"Action '{api_id}' not in available actions: {available_actions_and_info.keys()}")
        print(f"Selected action: {api_id}")
        self.custom_stream.log_activity("ActionExecutive", f"Selected action: {api_id}")
        return api_id
    
    # after infering the best tool, infer the best action
    def _infer_from_actions(self, user_input, available_actions_and_info, current_state):
        """Run the process using the runnable to handle logic flow."""
        current_goal = self.guide.state_manager.get_state_goal(current_state)
        if available_actions_and_info is None:
            available_actions_and_info = {}
            actions_available = self.guide.state_manager.get_actions_available(current_state)
            for action in actions_available:
                available_actions_and_info[action] = self.guide.action_manager.get_action_info(action)
        return self.action_runnable.invoke(user_input, current_state, current_goal, available_actions_and_info)
    
    def decide_action(self, user_input, current_state):
        """Decide the best action to take. Returns None if no action is to be taken."""
        api_id = self._infer_from_tools(user_input, current_state)
        return api_id
    
    def take_action(self, user_input, api_id):
        """Attempt to execute the action."""
        # If more params are needed, ask the user for more info or if the user needs to be asked permission to execute action
        #### PLACE HOLDER ####
        # Can also wait for goal completion, continuously execute actions until goal is met. Make a goal checker.
        #### PLACE HOLDER ####
        if api_id is None:
            return None
        return self.api_agent.make_request(api_id, user_input=user_input)

__all__ = ["ActionExecutive"]