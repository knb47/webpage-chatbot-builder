from app.agents.state_agent import NextStateAgentRunnable
from dependency_injector.wiring import Provide
from app.containers.containers import Container
import logging

class StateExecutive:
    """Manages the initialization and interaction with the runnable for state changes."""
    custom_stream: Container.custom_stream = Provide[Container.custom_stream]
    
    def __init__(self, guide, llm):
        self.runnable = NextStateAgentRunnable(llm)
        self.guide = guide

    def attempt_new_state(self, user_input, current_state):
        """Run the process using the runnable to handle logic flow."""
        if current_state is None or current_state == '':
            current_state = self.guide.state_manager.get_initial_state()
        next_state_response = self.runnable.invoke(
            user_input,
            current_state,
            self.guide.state_manager.get_next_states_and_conditions(current_state)
        )
        
        try:
            if next_state_response != "defer":
                print(f"StateExecutive decided a new state: {next_state_response}")
                if self.guide.state_manager.is_valid_state(current_state, next_state_response):
                    self.custom_stream.log_activity("StateExecutive", "Based on the user input, the current state is now: " + next_state_response)
                    print(f"State change successful.")
                    return next_state_response
            self.custom_stream.log_activity("StateExecutive", "Based on the user input, we will remain in the same state.")
            return current_state
        
        except Exception as e:
            print(f"Failed to change state: {e}")

        # current_goal = self.guide.state_manager.get_state_goal(current_state)
        # info_to_provide = self.guide.state_manager.get_provide_info(current_state)
        # self.custom_stream.log_activity("context_agent", f'{{"Here is your goal to accomplish as an assistant assisting the user in this phase: {current_goal}"}}')
        # self.custom_stream.log_activity("context_agent", f'{{"Here is some information you can synthesize and provide to the user to help guide the user in this phase: {info_to_provide}"}}')
        
        return next_state_response

__all__ = ["StateExecutive"]