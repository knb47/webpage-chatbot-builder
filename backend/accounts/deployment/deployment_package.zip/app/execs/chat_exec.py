from app.agents.chat_agent import ChatAgentRunnable
from dependency_injector.wiring import Provide
from app.containers.containers import Container
import logging
from pydantic import BaseModel

class ChatArgs(BaseModel):
  user_input: str
  context: str
  current_state: str
  goal: str
  info: str
  trigger: str
  next_state_triggers: dict
  actions: dict

class ChatExecutive:
    """Manages the initialization and interaction with the runnable for state changes."""
    custom_stream: Container.custom_stream = Provide[Container.custom_stream]
    
    def __init__(self, guide, llm):
        self.chat_runnable = ChatAgentRunnable(llm)

    def generate_response(self, chat_args: ChatArgs):
        """Run the process using the runnable to handle logic flow."""
        try:
            response_to_user = self.chat_runnable.invoke(chat_args)
            return response_to_user
        except Exception as e:
            print(f"Failed to change state: {e}")
            return None
        

__all__ = ["ChatExecutive"]