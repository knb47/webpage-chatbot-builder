from app.agents.state_agent import NextStateAgentRunnable
from dependency_injector.wiring import Provide
from app.containers.containers import Container

class APIExec:
    """Manages the initialization and interaction with the runnable for state changes."""
    custom_stream: Container.custom_stream = Provide[Container.custom_stream]
    
    def __init__(self, guide, llm):
        self.guide = guide

    
__all__ = ["StateExecutive"]